package com.java.Exception;

public class OrderCreationException extends Exception {
	public OrderCreationException(String message) {
    	super(message);
	}
}
