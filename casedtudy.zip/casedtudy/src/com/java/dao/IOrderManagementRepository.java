package com.java.dao;

import java.util.List;
import com.java.model.User;
import com.java.Exception.OrderNotFoundException;
import com.java.Exception.ProductNotFoundException;
import com.java.Exception.UserNotFoundException;
import com.java.model.Product;

public interface IOrderManagementRepository {
    void createOrder(User user, List<Product> products) throws UserNotFoundException;
    void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException;
    void createProduct(User user, Product product) throws UserNotFoundException;
    void createUser(User user);
    List<Product> getAllProducts();
    List<Product> getOrderByUser(User user) throws UserNotFoundException;
    User getUserById(int userId) throws UserNotFoundException; 
    Product getProductById(int productId) throws ProductNotFoundException;
}
