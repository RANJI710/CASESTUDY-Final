package com.java.dao;

import java.sql.*;
import java.util.*;

import com.java.Exception.OrderNotFoundException;
import com.java.Exception.ProductNotFoundException;
import com.java.Exception.UserNotFoundException;
import com.java.model.*;

public class OrderProcessor implements IOrderManagementRepository {
    private Map<Integer, User> users = new HashMap<>();
    private Map<Integer, Product> products = new HashMap<>();
    private Map<Integer, List<Product>> orders = new HashMap<>();
    private int orderIdCounter = 1;
    private Connection connection; 

    public OrderProcessor(Connection connection) {
        this.connection = connection; 
    }

    @Override
    
public void createOrder(User user, List<Product> products) throws UserNotFoundException {
    try {
        
        getUserById(user.getUserId());
        
        
        for (Product product : products) {
            String sql = "INSERT INTO orders (user_id, product_id, quantity) VALUES (?, ?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setInt(1, user.getUserId());
                ps.setInt(2, product.getProductId());
                
                ps.setInt(3, 1);
                ps.executeUpdate();
            }
        }
        System.out.println("Order created successfully.");
    } catch (SQLException e) {
        e.printStackTrace();
        throw new UserNotFoundException("Failed to create order: " + e.getMessage());
    }
}


    @Override
    public void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException {
        if (!users.containsKey(userId)) {
            throw new UserNotFoundException("User not found.");
        }
        if (!orders.containsKey(orderId)) {
            throw new OrderNotFoundException("Order not found.");
        }
        orders.remove(orderId);
    }

    @Override
    public void createProduct(User user, Product product) throws UserNotFoundException {
        if (!users.containsKey(user.getUserId()) || !user.getRole().equals("Admin")) {
            throw new UserNotFoundException("Admin user not found.");
        }
        products.put(product.getProductId(), product);
    }

    @Override
    public void createUser(User user) {
        
        try {
            PreparedStatement ps = connection.prepareStatement("INSERT INTO user (userid, username, password, role) VALUES (?, ?, ?, ?)");
            ps.setInt(1, user.getUserId());
            ps.setString(2, user.getUsername());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getRole());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    

    @Override
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery("SELECT * FROM product");
            while (rs.next()) {
                int id = rs.getInt("productid");
                String name = rs.getString("productname");
                String description = rs.getString("description");
                double price = rs.getDouble("price");
                int quantity = rs.getInt("quantityinstock");
                String type = rs.getString("type");
                if (type.equalsIgnoreCase("Electronics")) {
                    String brand = rs.getString("brand");
                    int warranty = rs.getInt("warrantyperiod");
                    productList.add(new Electronics(id, name, description, price, quantity, type, brand, warranty));
                } else if (type.equalsIgnoreCase("Clothing")) {
                    String size = rs.getString("size");
                    String color = rs.getString("color");
                    productList.add(new Clothing(id, name, description, price, quantity, type, size, color));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
           
        }
        return productList;
    }
    

    @Override
    public List<Product> getOrderByUser(User user) throws UserNotFoundException {
        if (!users.containsKey(user.getUserId())) {
            throw new UserNotFoundException("User not found.");
        }
        List<Product> userOrders = new ArrayList<>();
        for (List<Product> order : orders.values()) {
            userOrders.addAll(order);
        }
        return userOrders;
    }

    @Override
    public User getUserById(int userId) throws UserNotFoundException {
        try {
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM user WHERE userid = ?");
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                int id = rs.getInt("userid");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String role = rs.getString("role");
                
                return new User(id, username, password, role);
            } else {
                throw new UserNotFoundException("User not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new UserNotFoundException("User not found.");
        }
    }
    public void createOrder(User user, List<Product> products, int quantity) throws SQLException, ProductNotFoundException {
        String sql = "INSERT INTO orders (user_id, product_id, quantity) VALUES (?, ?, ?)";
    
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            for (Product product : products) {
                
                if (getProductById(product.getProductId()).getQuantityInStock() < quantity) {
                    throw new SQLException("Insufficient product stock for order.");
                }
    
                ps.setInt(1, user.getUserId());
                ps.setInt(2, product.getProductId());
                ps.setInt(3, quantity);
                ps.addBatch();
    
                // Update product stock after adding to batch
                product.setQuantityInStock(product.getQuantityInStock() - quantity);
            }
            ps.executeBatch();
        }
    }

    @Override
public Product getProductById(int productId) throws ProductNotFoundException {
    try {
        PreparedStatement ps = connection.prepareStatement("SELECT * FROM product WHERE productid = ?");
        ps.setInt(1, productId);
        ResultSet rs = ps.executeQuery();
        
        if (rs.next()) {
            int id = rs.getInt("productid");
            String name = rs.getString("productname");
            String description = rs.getString("description");
            double price = rs.getDouble("price");
            int quantityInStock = rs.getInt("quantityinstock");
            String type = rs.getString("type");
            if (type.equalsIgnoreCase("Electronics")) {
                String brand = rs.getString("brand");
                int warranty = rs.getInt("warrantyperiod");
                return new Electronics(id, name, description, price, quantityInStock, type, brand, warranty);
            } else if (type.equalsIgnoreCase("Clothing")) {
                String size = rs.getString("size");
                String color = rs.getString("color");
                return new Clothing(id, name, description, price, quantityInStock, type, size, color);
            }
        }
        throw new ProductNotFoundException("Product not found.");
    } catch (SQLException e) {
        e.printStackTrace();
        throw new ProductNotFoundException("Product not found.");
    }
}

    
}
