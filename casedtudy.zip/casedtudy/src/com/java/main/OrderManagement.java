package com.java.main;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.java.dao.OrderProcessor;
import com.java.Exception.OrderNotFoundException;
import com.java.Exception.UserNotFoundException;
import com.java.Exception.ProductNotFoundException;
import com.java.model.*;
import com.java.util.DBUtil;

public class OrderManagement {
    private static Scanner scanner = new Scanner(System.in);
    private static OrderProcessor orderProcessor;

    public static void main(String[] args) {
        try (Connection connection = DBUtil.getConnect()) {
            orderProcessor = new OrderProcessor(connection);

            while (true) {
                System.out.println("Enter choice: createUser, createProduct, createOrder, cancelOrder, getAllProducts, getOrderbyUser, exit");
                String choice = scanner.nextLine();

                switch (choice) {
                    case "createUser":
                        createUser();
                        break;
                    case "createProduct":
                        createProduct(scanner, orderProcessor);
                        break;
                    case "createOrder":
                        createOrder();
                        break;
                    case "cancelOrder":
                        cancelOrder();
                        break;
                    case "getAllProducts":
                        getAllProducts();
                        break;
                    case "getOrderbyUser":
                        getOrderByUser();
                        break;
                    case "exit":
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void createUser() {
        System.out.println("Enter userId:");
        int userId = Integer.parseInt(scanner.nextLine());
        System.out.println("Enter username:");
        String username = scanner.nextLine();
        System.out.println("Enter password:");
        String password = scanner.nextLine();
        System.out.println("Enter role (Admin/User):");
        String role = scanner.nextLine();

        User user = new User(userId, username, password, role);
        orderProcessor.createUser(user);
        System.out.println("User created successfully.");
    }

    private static void createProduct(Scanner scanner, OrderProcessor orderProcessor) {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter product name: ");
        String productName = scanner.nextLine();
        System.out.print("Enter description: ");
        String description = scanner.nextLine();
        System.out.print("Enter price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Enter quantity in stock: ");
        int quantityInStock = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter type (Electronics/Clothing): ");
        String type = scanner.nextLine();

        Product product = new Product(productId, productName, description, price, quantityInStock, type);
        try {
            orderProcessor.createProduct(null, product); 
        } catch (UserNotFoundException e) {
            System.err.println("User not found: " + e.getMessage());
        }
    }
    
    

    private static void createOrder() {
        System.out.println("Enter userId:");
        int userId = Integer.parseInt(scanner.nextLine());

        List<Product> productList = new ArrayList<>();
        while (true) {
            System.out.println("Enter productId (or 'done' to finish):");
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("done")) {
                break;
            }
            int productId = Integer.parseInt(input);

            try {
                Product product = getProductById(productId);
                productList.add(product);
            } catch (Exception e) {
                System.out.println("Product not found.");
            }
        }

        try {
            User user = orderProcessor.getUserById(userId);
            orderProcessor.createOrder(user, productList);
            System.out.println("Order created successfully.");
        } catch (UserNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    
    private static Product getProductById(int productId) throws ProductNotFoundException {
        try {
            return orderProcessor.getProductById(productId); // Delegate to OrderProcessor
        } catch (Exception e) {
            throw new ProductNotFoundException("Product not found. Database error: " + e.getMessage());
        }
    }
    

    private static void cancelOrder() {
        System.out.println("Enter userId:");
        int userId = Integer.parseInt(scanner.nextLine());
        System.out.println("Enter orderId:");
        int orderId = Integer.parseInt(scanner.nextLine());

        try {
            orderProcessor.cancelOrder(userId, orderId);
            System.out.println("Order canceled successfully.");
        } catch (UserNotFoundException | OrderNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void getAllProducts() {
        List<Product> products = orderProcessor.getAllProducts();
        if (products.isEmpty()) {
            System.out.println("No products found.");
        } else {
            for (Product product : products) {
                System.out.println(product.getProductName() + " - " + product.getDescription());
            }
        }
    }

    private static void getOrderByUser() {
        System.out.println("Enter userId:");
        int userId = Integer.parseInt(scanner.nextLine());

        try {
            User user = orderProcessor.getUserById(userId);
            List<Product> userOrders = orderProcessor.getOrderByUser(user);
            if (userOrders.isEmpty()) {
                System.out.println("No orders found for this user.");
            } else {
                for (Product product : userOrders) {
                    System.out.println(product.getProductName() + " - " + product.getDescription());
                }
            }
        } catch (UserNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
